// Before starting, copy and paste your guided practice work from
// `binary-search-tree.js` into this file

// Your code here